Chattr
======

A video chat communication site based on WebRTC. To run the server have the following dependencies installed:

- Node.js 

Then type node server.js and visit localhost:4000
